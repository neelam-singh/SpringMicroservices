package movie.catalog.service.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import movie.catalog.service.model.CatalogItem;
import movie.catalog.service.model.Movie;
import movie.catalog.service.model.Rating;

@Service
public class MovieInfo {
	
	@Autowired
	RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod = "getCatalogItemFallBack")
	public CatalogItem getCatalogItem(Rating rating) {
		Movie movie = restTemplate.getForObject("http://movie-info-service/movie/"+rating.getMovieId(), Movie.class);
		/*
		 * Movie movie = webBuilder.build() .get()
		 * .uri("http://localhost:8081/movie/"+rating.getMovieId()) .retrieve()
		 * .bodyToMono(Movie.class) .block();
		 */
		return new CatalogItem(movie.getMovieId(), "test", rating.getRating());
	}
	
	public CatalogItem getCatalogItemFallBack(Rating rating) {
		
		Movie movie = new Movie(rating.getMovieId(), "Default Name");
		/*
		 * Movie movie = webBuilder.build() .get()
		 * .uri("http://localhost:8081/movie/"+rating.getMovieId()) .retrieve()
		 * .bodyToMono(Movie.class) .block();
		 */
		return new CatalogItem(movie.getMovieId(), "No movie", rating.getRating());
	}

}
