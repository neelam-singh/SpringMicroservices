package movie.catalog.service.services;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import movie.catalog.service.model.Rating;
import movie.catalog.service.model.UserRating;

@Service
public class RatingInfo {
	
	@Autowired
	RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod = "getRatingFallBack")
	public UserRating getRating(String userID)
	{
		return restTemplate.getForObject("http://movie-rating-service/rating/user/"+userID, UserRating.class);
	}
	
	public UserRating getRatingFallBack(String userID)
	{
		UserRating userRating = new UserRating();
		userRating.setUserRatingList(Arrays.asList(new Rating(userID, 0)));
		return userRating;
	}

}
