package movie.catalog.service.model;

import java.util.List;
import movie.catalog.service.model.Rating;

public class UserRating {
	
	List<Rating> userRatingList;

	public List<Rating> getUserRatingList() {
		return userRatingList;
	}

	public void setUserRatingList(List<Rating> userRatingList) {
		this.userRatingList = userRatingList;
	}
	
	

}
