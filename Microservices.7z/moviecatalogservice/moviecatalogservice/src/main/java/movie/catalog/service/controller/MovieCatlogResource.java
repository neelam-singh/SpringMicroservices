package movie.catalog.service.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import movie.catalog.service.model.CatalogItem;
import movie.catalog.service.model.Movie;
import movie.catalog.service.model.Rating;
import movie.catalog.service.model.UserRating;
import movie.catalog.service.services.MovieInfo;
import movie.catalog.service.services.RatingInfo;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/catalog")
public class MovieCatlogResource {
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	MovieInfo movieInfo;
	
	@Autowired
	RatingInfo ratingInfo;
	
	@Autowired
	WebClient.Builder webBuilder;
	
	@RequestMapping("/{userID}")
	//@HystrixCommand(fallbackMethod = "getCatalogFallBack")
	public List<CatalogItem> getCatalog(@PathVariable("userID") String userID)
	{
		
		//List<Rating> ratingList = Arrays.asList(new Rating("1234", 4), new Rating("4567", 3));
		
		UserRating ratingList = ratingInfo.getRating(userID);
		
		return ratingList.getUserRatingList().stream()
				.map(rating-> movieInfo.getCatalogItem(rating))
				.collect(Collectors.toList());
		
		/*
		 * List<CatalogItem> catItems = new ArrayList<>(); catItems.add(new
		 * CatalogItem("Transformer", "test", 4)); return catItems;
		 */
	}
	
	
	public List<CatalogItem> getCatalogFallBack(@PathVariable("userID") String userID)
	{
		return Arrays.asList(new CatalogItem("No Movie", "No desc", 0));
	}

}
