package movie.catalog.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviecatalogserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
