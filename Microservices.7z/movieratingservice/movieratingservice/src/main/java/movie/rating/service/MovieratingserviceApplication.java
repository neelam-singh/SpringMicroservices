package movie.rating.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieratingserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieratingserviceApplication.class, args);
	}

}
