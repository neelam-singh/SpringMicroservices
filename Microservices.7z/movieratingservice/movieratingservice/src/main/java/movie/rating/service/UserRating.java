package movie.rating.service;

import java.util.List;

import movie.rating.service.model.Rating;

public class UserRating {
	
	List<Rating> userRatingList;

	public List<Rating> getUserRatingList() {
		return userRatingList;
	}

	public void setUserRatingList(List<Rating> userRatingList) {
		this.userRatingList = userRatingList;
	}
	
	

}
