package movie.rating.service.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import movie.rating.service.UserRating;
import movie.rating.service.model.Rating;

@RestController
@RequestMapping("/rating")
public class MovieRatingResource {
	
	@RequestMapping("/{movieID}")
	public Rating getMovieRating(@PathVariable("movieID") String movieID)
	{
		return new Rating(movieID, 4);
	}
	
	@RequestMapping("/user/{userID}")
	public UserRating getRatingList(@PathVariable("userID") String userID)
	{
		List<Rating> ratingList = Arrays.asList(new Rating("100", 4), new Rating("200", 3));
		
		UserRating userRating = new UserRating();
		userRating.setUserRatingList(ratingList);
		return userRating;
	}

}
